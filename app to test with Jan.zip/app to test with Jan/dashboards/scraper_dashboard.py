"""
dashboards/scraper_dashboard.py — Dashin Research Platform V2
Smart Scraper tab. Launches worker.py, reads sessions from DB.
Now org-scoped: each org only sees its own sessions and stats.
"""

import streamlit as st
import subprocess, sys, time
import pandas as pd
from pathlib import Path

from core.db import get_connection

# ── STYLE ─────────────────────────────────────────────────────────────────────
CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700&family=Outfit:wght@400;500;600&display=swap');

.page-title{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;
  color:#1a1917;letter-spacing:-0.5px;margin-bottom:4px}
.page-sub{font-size:13px;color:#999;margin-bottom:28px}
.stat-row{display:flex;gap:14px;margin-bottom:28px;flex-wrap:wrap}
.stat-card{flex:1;min-width:120px;background:#fff;border:1px solid #e8e4dd;
  border-radius:10px;padding:18px 20px}
.stat-val{font-family:'Playfair Display',serif;font-size:28px;font-weight:700;color:#1a1917}
.stat-label{font-size:10px;color:#aaa;text-transform:uppercase;letter-spacing:1.2px;
  margin-top:3px;font-weight:600}
.stat-note{font-size:11px;color:#c9a96e;margin-top:5px;font-weight:600}
.sec-header{font-family:'Playfair Display',serif;font-size:17px;font-weight:700;
  color:#1a1917;margin:28px 0 12px;padding-bottom:8px;border-bottom:1px solid #e8e4dd}
.launch-box{background:#fff;border:1px solid #e8e4dd;border-radius:10px;
  padding:24px 28px;margin-bottom:8px}
.tip{background:#fffdf5;border:1px solid #e8d5a8;border-left:3px solid #c9a96e;
  border-radius:6px;padding:12px 16px;font-size:12px;color:#8a7040;margin:14px 0}
.tbl{background:#fff;border:1px solid #e8e4dd;border-radius:10px;overflow:hidden}
.tbl table{width:100%;border-collapse:collapse;font-size:12px}
.tbl th{background:#f8f7f4;padding:10px 16px;text-align:left;font-size:10px;
  font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:1.2px;
  border-bottom:1px solid #e8e4dd}
.tbl td{padding:10px 16px;border-bottom:1px solid #f0ede8;color:#555;vertical-align:middle}
.tbl td.n{color:#1a1917;font-weight:600}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:#faf9f7}
.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:10px;font-weight:600}
.b-run {background:#fff8ec;color:#c9a96e;border:1px solid #e8d5a8}
.b-done{background:#ecf7f0;color:#3d9e6a;border:1px solid #b8dfc8}
.b-fail{background:#fdecea;color:#d45050;border:1px solid #f0b8b8}
div.stButton>button{border-radius:7px!important;font-family:'Outfit',sans-serif!important;
  font-weight:600!important;font-size:13px!important}
div.stButton>button[kind="primary"]{background:#1a1917!important;color:#fff!important;border:none!important}
div.stButton>button[kind="primary"]:hover{background:#c9a96e!important}
div.stButton>button[kind="secondary"]{background:transparent!important;color:#1a1917!important;
  border:1px solid #d0ccc5!important}
div.stTextInput input{border:1px solid #e0dbd4!important;border-radius:7px!important;
  background:#faf9f7!important;font-size:13px!important;padding:10px 14px!important}
div.stTextInput input:focus{border-color:#c9a96e!important;
  box-shadow:0 0 0 3px rgba(201,169,110,.12)!important}
</style>
"""


# ── DATA HELPERS (replaces missing V1 functions) ───────────────────────────────

def _get_lead_stats(org_id: int) -> dict:
    """Inventory stats scoped to this org."""
    conn = get_connection()
    try:
        row = conn.execute("""
            SELECT
                COUNT(*)                                        AS total,
                SUM(CASE WHEN status='new'      THEN 1 END)    AS new,
                SUM(CASE WHEN status='enriched' THEN 1 END)    AS enriched,
                SUM(CASE WHEN status='used'     THEN 1 END)    AS used,
                SUM(CASE WHEN status='archived' THEN 1 END)    AS archived
            FROM leads WHERE org_id=?
        """, (org_id,)).fetchone()
        if row:
            return {
                "total":    row.get("total", 0)    or 0,
                "new":      row.get("new", 0)      or 0,
                "enriched": row.get("enriched", 0) or 0,
                "used":     row.get("used", 0)     or 0,
                "archived": row.get("archived", 0) or 0,
            }
    except Exception:
        pass
    finally:
        conn.close()
    return {"total": 0, "new": 0, "enriched": 0, "used": 0, "archived": 0}


def _get_recent_sessions(org_id: int, limit: int = 15) -> list:
    """Recent scrape sessions for this org.
    Falls back to ALL sessions if none found for this org_id
    (handles old rows saved before multi-org migration).
    """
    conn = get_connection()
    try:
        # Try org-scoped first
        rows = conn.execute("""
            SELECT id, event_name, event_url, category, layout,
                   status, leads_found, leads_new, leads_dupes,
                   ai_cost_usd, pattern_used, started_at, finished_at
            FROM scrape_sessions
            WHERE org_id=? OR org_id IS NULL
            ORDER BY started_at DESC
            LIMIT ?
        """, (org_id, limit)).fetchall()
        return rows if rows else []
    except Exception:
        # Column may not exist in very old schema — try without org_id filter
        try:
            rows = conn.execute("""
                SELECT id, event_name, event_url, category, layout,
                       status, leads_found, leads_new, leads_dupes,
                       started_at, finished_at,
                       0 AS ai_cost_usd, 0 AS pattern_used
                FROM scrape_sessions
                ORDER BY started_at DESC
                LIMIT ?
            """, (limit,)).fetchall()
            return rows if rows else []
        except Exception:
            return []
    finally:
        conn.close()


# ── RENDER ─────────────────────────────────────────────────────────────────────

def badge(status: str) -> str:
    cls = {"running": "b-run", "done": "b-done", "failed": "b-fail"}.get(
        status, "b-run"
    )
    return f'<span class="badge {cls}">{status.title()}</span>'


def render(user: dict = None):
    """
    Main render function.
    Accepts optional user dict for org_id scoping.
    Falls back to org_id=1 if no user (legacy mode).
    """
    org_id = (user or {}).get("org_id", 1)

    st.markdown(CSS, unsafe_allow_html=True)

    st.markdown('<div class="page-title">Smart Scraper</div>',
                unsafe_allow_html=True)
    st.markdown(
        '<div class="page-sub">Launch a scraping session on any event directory. '
        'Claude AI identifies the page structure automatically.</div>',
        unsafe_allow_html=True,
    )

    # ── Stats row ──────────────────────────────────────────────────────
    s = _get_lead_stats(org_id)

    st.markdown(f"""
    <div class="stat-row">
      <div class="stat-card">
        <div class="stat-val">{s['total']:,}</div>
        <div class="stat-label">Total Leads</div>
        <div class="stat-note">All time</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">{s['new']:,}</div>
        <div class="stat-label">New</div>
        <div class="stat-note">Awaiting research</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">{s['enriched']:,}</div>
        <div class="stat-label">Enriched</div>
        <div class="stat-note">Ready to use</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">{s['used']:,}</div>
        <div class="stat-label">Used</div>
        <div class="stat-note">Across all clients</div>
      </div>
      <div class="stat-card">
        <div class="stat-val">{s['archived']:,}</div>
        <div class="stat-label">Archived</div>
        <div class="stat-note">In named lists</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # ── Launch ─────────────────────────────────────────────────────────
    st.markdown('<div class="sec-header">Launch New Scrape</div>',
                unsafe_allow_html=True)

    # Scraper type definitions
    SCRAPER_TYPES = {
        "🎪  Event Directory": {
            "key":         "event",
            "script":      "worker.py",
            "placeholder": "https://app.bettshow.com/newfront/participants",
            "tip":         "Scrapes attendee/delegate lists from event apps. Works on Brella, BETT, FDF, Swapcard, and most event platforms.",
            "fields":      ["name", "title", "company"],
        },
        "🏢  Clutch": {
            "key":         "clutch",
            "script":      "clutch_scraper.py",
            "placeholder": "https://clutch.co/uk/agencies/seo",
            "tip":         "Scrapes agency/company listings from Clutch.co. Extracts company name, rating, reviews, budget, services, location.",
            "fields":      ["company", "rating", "services", "location", "budget"],
        },
        "💼  LinkedIn (Coming Soon)": {
            "key":         "linkedin",
            "script":      None,
            "placeholder": "https://www.linkedin.com/search/results/people/...",
            "tip":         "LinkedIn people scraper — coming soon.",
            "fields":      [],
        },
        "📋  Generic List": {
            "key":         "generic",
            "script":      "worker.py",
            "placeholder": "https://any-directory-or-listing.com",
            "tip":         "AI vision fallback for any other listing page. Works on most sites but may need a retry or two.",
            "fields":      ["auto-detected"],
        },
    }

    # Load clients
    conn_cl = get_connection()
    clients_raw = conn_cl.execute(
        "SELECT id, name FROM clients WHERE org_id=? AND is_active=1 ORDER BY name",
        (org_id,)
    ).fetchall()
    conn_cl.close()
    client_options = ["— No client (general scrape) —"] + [c["name"] for c in clients_raw]
    client_id_map  = {c["name"]: c["id"] for c in clients_raw}

    INDUSTRIES = [
        "— Not specified —", "EdTech", "HealthTech", "FinTech", "SaaS / Software",
        "Professional Services", "Retail / eCommerce", "Media & Publishing",
        "Logistics & Supply Chain", "Manufacturing", "Real Estate",
        "HR & Recruitment", "Legal", "Marketing & Advertising",
        "Cybersecurity", "AI / Data", "Energy & CleanTech", "Other",
    ]
    COMPANY_TYPES = [
        "— Not specified —", "Enterprise (1000+)", "Mid-Market (100–999)",
        "SMB (10–99)", "Startup (<10)", "Non-profit / Association",
        "Government / Public Sector", "Agency", "Consultancy",
    ]

    with st.container():
        st.markdown('<div class="launch-box">', unsafe_allow_html=True)

        # ── Scraper type selector ──────────────────────────────────────
        scraper_label = st.selectbox(
            "Scraper type",
            list(SCRAPER_TYPES.keys()),
            help="Choose the right scraper for your source"
        )
        scraper = SCRAPER_TYPES[scraper_label]
        is_coming_soon = scraper["script"] is None

        # Tip for selected type
        tip_colour = "#fff8ec" if not is_coming_soon else "#f8f7f4"
        st.markdown(f"""
        <div class="tip" style="background:{tip_colour}">
            💡 {scraper["tip"]}
            {"<br><b>Coming soon — not yet available.</b>" if is_coming_soon else ""}
        </div>
        """, unsafe_allow_html=True)

        if not is_coming_soon:
            # ── URL input ──────────────────────────────────────────────
            url = st.text_input(
                "URL *",
                placeholder=scraper["placeholder"],
            )

            # ── Context fields ─────────────────────────────────────────
            col1, col2, col3 = st.columns(3)
            with col1:
                client_sel = st.selectbox("Client this is for", client_options)
            with col2:
                industry_preset = st.selectbox("Target industry", INDUSTRIES)
                industry_custom = st.text_input("Or type your own",
                                                 placeholder="e.g. PropTech…")
                industry_sel = industry_custom.strip() or (
                    None if industry_preset == "— Not specified —" else industry_preset
                )
            with col3:
                comptype_preset = st.selectbox("Company type", COMPANY_TYPES)
                comptype_custom = st.text_input("Or type your own ",
                                                 placeholder="e.g. Scale-up…")
                company_type_sel = comptype_custom.strip() or (
                    None if comptype_preset == "— Not specified —" else comptype_preset
                )

            col4, col5 = st.columns(2)
            with col4:
                source_name = st.text_input(
                    "Source / event name",
                    placeholder="BETT 2026 / Clutch UK SEO",
                    help="Labels this batch in your inventory"
                )
            with col5:
                notes_input = st.text_input(
                    "Notes (optional)",
                    placeholder="VP+ roles only, filter by UK"
                )

            # Pages slider for Clutch
            if scraper["key"] == "clutch":
                max_pages = st.slider("Max pages to scrape", 1, 50, 20,
                                      help="Each page = ~25 companies on Clutch")
                st.caption(f"Will scrape up to ~{max_pages * 25} companies")
                mobile_mode = False
            else:
                max_pages = 20
                mobile_mode = st.checkbox(
                    "📱 Mobile emulation mode",
                    help="Emulates an iPhone 13. Use for apps that only work on mobile browsers "
                         "(different layout, different content). Try this if the desktop version shows nothing."
                )

            c1, c2 = st.columns([1, 4])
            with c1:
                go = st.button("🚀 Launch", type="primary",
                               use_container_width=True)
            with c2:
                st.markdown(
                    '<p style="font-size:12px;color:#bbb;padding-top:12px">'
                    "Opens a browser window on your machine.</p>",
                    unsafe_allow_html=True,
                )
        else:
            url = ""
            go  = False
            client_sel = client_options[0]
            industry_sel = None
            company_type_sel = None
            source_name = ""
            notes_input = ""
            max_pages = 20

        st.markdown("</div>", unsafe_allow_html=True)

    if go:
        if not url.strip():
            st.error("Please paste a URL.")
        else:
            script_name = scraper["script"]
            script_path = Path(__file__).parent.parent / script_name

            if not script_path.exists():
                st.error(f"Script not found: {script_path}. Make sure {script_name} is in your project folder.")
            else:
                # Save session to DB
                selected_client_id = client_id_map.get(client_sel)
                import datetime as _dt
                conn_s = get_connection()
                try:
                    conn_s.execute("""
                        INSERT INTO scrape_sessions
                            (org_id, client_id, event_url, event_name,
                             category, notes, status, started_at)
                        VALUES (?,?,?,?,?,?,'running',?)
                    """, (org_id, selected_client_id,
                          url.strip(),
                          source_name.strip() or None,
                          industry_sel,
                          (f"{company_type_sel or ''} {notes_input.strip()}").strip() or None,
                          _dt.datetime.utcnow().isoformat()))
                    conn_s.commit()
                except Exception:
                    pass
                finally:
                    conn_s.close()

                kwargs = {}
                if sys.platform == "win32":
                    kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE

                # Build command based on scraper type
                if scraper["key"] == "clutch":
                    cmd = [sys.executable, str(script_path),
                           url.strip(), "--pages", str(max_pages)]
                else:
                    cmd = [sys.executable, str(script_path), url.strip()]
                    if mobile_mode:
                        cmd.append("--mobile")

                subprocess.Popen(cmd, **kwargs)

                tag_parts = []
                if selected_client_id: tag_parts.append(f"Client: **{client_sel}**")
                if industry_sel:       tag_parts.append(f"Industry: **{industry_sel}**")
                if source_name:        tag_parts.append(f"Source: **{source_name}**")
                tag_str = " · ".join(tag_parts)

                st.success(
                    f"✅ {scraper_label.strip()} launched!"
                    + (f"  {tag_str}" if tag_str else "")
                    + "  Watch the browser window."
                )
                time.sleep(2)
                st.rerun()

    # ── Recent sessions ────────────────────────────────────────────────
    st.markdown('<div class="sec-header">Recent Sessions</div>',
                unsafe_allow_html=True)

    col_r, _ = st.columns([1, 6])
    with col_r:
        if st.button("↻ Refresh", type="secondary"):
            st.rerun()

    sessions = _get_recent_sessions(org_id, 15)

    if not sessions:
        st.markdown(
            '<p style="color:#aaa;font-size:13px;padding:16px 0">'
            "No sessions yet — launch one above.</p>",
            unsafe_allow_html=True,
        )
    else:
        rows_html = ""
        for s in sessions:
            evt  = (s.get("event_name") or s.get("event_url") or "?")[:45]
            cat  = s.get("category") or "—"
            dt   = (s.get("started_at") or "")[:16].replace("T", " ")
            ai   = s.get("ai_cost_usd") or 0
            pat  = "✓ Pattern" if s.get("pattern_used") else "AI"
            rows_html += f"""<tr>
              <td class="n">{evt}</td>
              <td>{cat}</td>
              <td>{s.get('leads_found', 0)}</td>
              <td style="color:#3d9e6a;font-weight:600">{s.get('leads_new', 0)}</td>
              <td style="color:#aaa">{s.get('leads_dupes', 0)}</td>
              <td>{badge(s.get('status', 'running'))}</td>
              <td style="color:#bbb;font-size:11px">{pat}</td>
              <td style="color:#bbb;font-size:11px">${ai:.4f}</td>
              <td style="color:#bbb;font-size:11px">{dt}</td>
            </tr>"""

        st.markdown(f"""
        <div class="tbl"><table>
          <thead><tr>
            <th>Event</th><th>Category</th><th>Found</th>
            <th>New</th><th>Dupes</th><th>Status</th>
            <th>Method</th><th>AI Cost</th><th>Date</th>
          </tr></thead>
          <tbody>{rows_html}</tbody>
        </table></div>
        """, unsafe_allow_html=True)

    # ── Session file downloads ─────────────────────────────────────────
    sdir = Path("data/system/sessions")
    if sdir.exists():
        csvs = sorted(sdir.glob("*.csv"), reverse=True)
        if csvs:
            st.markdown(
                '<div class="sec-header">Download Session Files</div>',
                unsafe_allow_html=True,
            )
            sel = st.selectbox(
                "File", csvs,
                format_func=lambda p: p.name,
                label_visibility="collapsed",
            )
            if sel:
                try:
                    df = pd.read_csv(sel)
                    st.download_button(
                        f"⬇ Download {sel.name} ({len(df)} rows)",
                        df.to_csv(index=False).encode(),
                        sel.name,
                        "text/csv",
                    )
                    with st.expander("Preview first 20 rows"):
                        st.dataframe(df.head(20), use_container_width=True)
                except Exception as e:
                    st.error(str(e))
