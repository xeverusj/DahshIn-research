"""
check_and_fix.py — Run this from your project root to diagnose and fix the source_type issue.
Usage: python check_and_fix.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from core.db import get_connection, init_db
init_db()
conn = get_connection()

print("\n" + "="*60)
print("  Dashin DB Diagnostic & Fix")
print("="*60 + "\n")

# 1. Check if source_type column exists
print("[1] Checking leads table columns...")
cols = conn.execute("PRAGMA table_info(leads)").fetchall()
col_names = [c["name"] for c in cols]
print(f"    Columns: {col_names}")

if "source_type" not in col_names:
    print("    ❌ source_type column MISSING — adding it now...")
    conn.execute("ALTER TABLE leads ADD COLUMN source_type TEXT DEFAULT 'event'")
    conn.commit()
    print("    ✅ source_type column added")
else:
    print("    ✅ source_type column exists")

# 2. Check current source_type distribution
print("\n[2] Checking source_type distribution...")
rows = conn.execute("""
    SELECT source_type, COUNT(*) as c FROM leads GROUP BY source_type
""").fetchall()
for r in rows:
    print(f"    source_type={r['source_type']!r:20} → {r['c']:,} leads")

# 3. Check enrichment for Agency leads
print("\n[3] Checking enrichment industry tags...")
agency_count = conn.execute("""
    SELECT COUNT(*) as c FROM enrichment WHERE industry = 'Agency / Services'
""").fetchone()["c"]
print(f"    'Agency / Services' enrichment rows: {agency_count:,}")

notes_count = conn.execute("""
    SELECT COUNT(*) as c FROM enrichment 
    WHERE notes IS NOT NULL AND notes LIKE '%rating%'
""").fetchone()["c"]
print(f"    Notes with 'rating' field: {notes_count:,}")

# 4. Import Clutch CSV companies into DB (they were never saved to DB)
print("\n[4] Importing Clutch companies from CSV files into database...")

import re as _re, pandas as pd, json, datetime as _dt

sessions_folder = ROOT / "data" / "system" / "sessions"
clutch_csvs = list(sessions_folder.glob("clutch_*.csv"))
print(f"    Found {len(clutch_csvs)} Clutch CSV file(s)")

total_imported = 0
total_skipped  = 0
now = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None).isoformat()

for csv_path in clutch_csvs:
    try:
        df = pd.read_csv(csv_path)
        if "company_name" not in df.columns:
            print(f"    Skipping {csv_path.name} — no company_name column")
            continue

        print(f"\n    Processing {csv_path.name} ({len(df)} rows)...")
        imported = 0
        skipped  = 0

        for _, row in df.iterrows():
            name = str(row.get("company_name","")).strip()
            if not name or name.lower() in ("nan","none",""):
                continue

            nk = _re.sub(r"[^a-z0-9]", "", name.lower())
            if not nk:
                continue

            # Check if already in DB
            existing = conn.execute(
                "SELECT id FROM leads WHERE name_key=? AND org_id=1", (nk,)
            ).fetchone()

            if existing:
                # Just tag it as clutch
                conn.execute(
                    "UPDATE leads SET source_type='clutch' WHERE name_key=? AND org_id=1", (nk,)
                )
                skipped += 1
                continue

            # Insert company
            co_existing = conn.execute(
                "SELECT id FROM companies WHERE name_key=? AND org_id=1", (nk,)
            ).fetchone()
            if co_existing:
                company_id = co_existing["id"]
            else:
                cur = conn.execute(
                    "INSERT INTO companies (org_id, name, name_key) VALUES (1,?,?)",
                    (name, nk)
                )
                company_id = cur.lastrowid

            # Insert lead
            location = str(row.get("location","")).strip()
            services = str(row.get("top_services","")).strip()
            cur = conn.execute("""
                INSERT OR IGNORE INTO leads
                    (org_id, full_name, name_key, title, company_id,
                     status, source_type, first_seen_at, last_seen_at, times_seen)
                VALUES (1, ?, ?, ?, ?, 'new', 'clutch', ?, ?, 1)
            """, (name, nk,
                  services[:100] if services and services != "nan" else None,
                  company_id, now, now))

            if cur.lastrowid:
                lead_id = cur.lastrowid
                # Save Clutch metadata to enrichment
                meta = {
                    "rating":      str(row.get("rating","")).strip(),
                    "reviews":     str(row.get("reviews","")).strip(),
                    "min_budget":  str(row.get("min_budget","")).strip(),
                    "hourly_rate": str(row.get("hourly_rate","")).strip(),
                    "team_size":   str(row.get("team_size","")).strip(),
                    "clutch_url":  str(row.get("clutch_url","")).strip(),
                    "website":     str(row.get("website","")).strip(),
                }
                conn.execute("""
                    INSERT OR IGNORE INTO enrichment
                        (lead_id, country, industry, notes, enriched_at)
                    VALUES (?,?,'Agency / Services',?,?)
                """, (lead_id,
                      location if location and location != "nan" else None,
                      json.dumps(meta), now))
                imported += 1
            else:
                skipped += 1

        conn.commit()
        total_imported += imported
        total_skipped  += skipped
        print(f"    ✅ {imported} new companies imported, {skipped} already existed (tagged)")

    except Exception as e:
        print(f"    ❌ Error processing {csv_path.name}: {e}")
        import traceback; traceback.print_exc()

print(f"\n    Total imported: {total_imported}")
print(f"    Total tagged/skipped: {total_skipped}")

# 5. Verify final state
print("\n[5] Final source_type distribution:")
rows = conn.execute("""
    SELECT source_type, COUNT(*) as c FROM leads GROUP BY source_type
""").fetchall()
for r in rows:
    print(f"    source_type={r['source_type']!r:20} → {r['c']:,} leads")

conn.close()

print("\n" + "="*60)
print("  Done. Restart Streamlit now.")
print("="*60 + "\n")
